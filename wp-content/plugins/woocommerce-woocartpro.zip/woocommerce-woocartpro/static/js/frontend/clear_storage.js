(function(jQuery) {
        sessionStorage.removeItem("wc_cart_hash");
        sessionStorage.removeItem("wc_fragments");
}(jQuery));
