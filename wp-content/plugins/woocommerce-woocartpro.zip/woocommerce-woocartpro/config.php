<?php
/* widget */
define('WOOCARTPRO_CART_WIDGET_ID', 'WooCartFestiWidget');